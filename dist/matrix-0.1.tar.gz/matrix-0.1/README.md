# matrix
This is a module to replicate matrix object to python and all its mathematical operators
